We maintain a knowledgebase at this [wiki](https://github.com/Significant-Gravitas/Nexus/wiki)

We would like to say "We value all contributions". After all, we are an open-source project, so we should say something fluffy like this, right?

However the reality is that some contributions are SUPER-valuable, while others create more trouble than they are worth and actually _create_ work for the core team.

If you wish to contribute, please look through the wiki [contributing](https://github.com/Significant-Gravitas/Nexus/wiki/Contributing) page.

If you wish to involve with the project (beyond just contributing PRs), please read the wiki [catalyzing](https://github.com/Significant-Gravitas/Nexus/wiki/Catalyzing) page.

In fact, why not just look through the whole wiki (it's only a few pages) and hop on our discord (you'll find it in the wiki).

❤️ & 🔆
The team @ Auto-GPT
